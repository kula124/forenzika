# Vjezbe 1

Prije riješavanja zadataka potrebno je instalirati PIL modul.

## Zad 5
Najvjernije izgleda zeleni kanal.

