# Lab 2

Vodeni žigovi se u obradi i analizi digitalnih slika koriste za prikrivanje informacija, te su stoga važni u forenzickoj analizi digitalnih slika.

## Zadatak 1

 Mjenjanjem skale vodeni žig je više odnosno manje vidljiv.

 ## Zadatak 2

 Mjenjanjem skale vodeni žig je više odnosno manje vidljiv.

 