# Lab 4

## Zadatak 1

### SHA-1

SHA-1 skraćenica je od engleske složenice Secure Hash Algorithm i ime je za algoritam koji služi za provjeru autentičnosti datoteka ili poruke prilikom prijenosa između pošiljaoca i primatelja. SHA-1 je nasljednik MD-5 i koristi se u raznim sigurnosnim programima ili u protokomima kao što su: TLS, SSL, PGP, SSH, S/MIME, i IPsec. SHA-1 je kompromitiran 2002. nakon čega je razvijena poboljšana inačica SHA-2.

## Zadatak 2

Nakon promjene slike hash se razlikuje što je za i očekivati.

## Zadatak 3

Median filter je nelinearna tehnika digitalnog filtriranja. Često se koristi za uklanjanja šuma iz slike ili signala. 
Uklanjanje šuma je čest predkorak s ciljem poboljšanja razultata daljnje obrade.   
Ideja algoritma je da se signal prođe segmet po segmet te se za svaki segment uzima srednja vrijednost u nekom intervalu susjednih segmenata.  
Koristi se za restauraciju starih i/ili oštećenih slika.